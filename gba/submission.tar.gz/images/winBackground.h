/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=240x160 winBackground winBackground.jpeg 
 * Time-stamp: Thursday 03/31/2022, 22:29:54
 * 
 * Image Information
 * -----------------
 * winBackground.jpeg 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef WINBACKGROUND_H
#define WINBACKGROUND_H

extern const unsigned short winBackground[38400];
#define WINBACKGROUND_SIZE 76800
#define WINBACKGROUND_LENGTH 38400
#define WINBACKGROUND_WIDTH 240
#define WINBACKGROUND_HEIGHT 160

#endif

