/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=50x37 pacman pacman.webp 
 * Time-stamp: Tuesday 04/05/2022, 03:00:42
 * 
 * Image Information
 * -----------------
 * pacman.webp 50@37
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef PACMAN_H
#define PACMAN_H

extern const unsigned short pacman[1850];
#define PACMAN_SIZE 3700
#define PACMAN_LENGTH 1850
#define PACMAN_WIDTH 50
#define PACMAN_HEIGHT 37

#endif

