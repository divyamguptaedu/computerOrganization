/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=240x160 loseBackground loseBackground.webp 
 * Time-stamp: Thursday 03/31/2022, 22:30:14
 * 
 * Image Information
 * -----------------
 * loseBackground.webp 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef LOSEBACKGROUND_H
#define LOSEBACKGROUND_H

extern const unsigned short loseBackground[38400];
#define LOSEBACKGROUND_SIZE 76800
#define LOSEBACKGROUND_LENGTH 38400
#define LOSEBACKGROUND_WIDTH 240
#define LOSEBACKGROUND_HEIGHT 160

#endif

